<?php
/*
 * This file is part of cred.
 *
 * (c) SIMON MUTUKU <https://github.com/eliasngumbi>
 *
 * Basic validator for form inputs
 */
 if(isset($_POST)){
  $expected = array('username', 'email', 'pwd', 'confirmPwd','accept');
  $required = array('username', 'email', 'pwd', 'confirmPwd','yestoTerms');
  $missing = array();
  
  
  foreach ($_POST as $key => $value) {
    $temp = is_array($value) ? $value : trim($value);
	
	if (empty($temp) && in_array($key, $required)) {
	  array_push($missing, $key);
	  }
	
	elseif (in_array($key, $expected)) {
	  ${$key} = $temp;
	  }
	}
	
	 if (!empty($email)) {
		 $checkEmail = '/^[^@]+@[^\s\r\n\'";,@%]+$/';
	if (!preg_match($checkEmail, $email)) {
	  array_push($missing, 'invalidEmail');
	  }
	}
	
	if (!empty($username)) {
		 $checkName = '/^[a-zA-Z0-9_]+$/';
	if (!preg_match($checkName, $username)) {
	  array_push($missing, 'invalidUsername');
	  }
	}
	hgb 
	if (!empty($_POST['pwd'])) {
	if (strlen($_POST['pwd']) < 5) {
	  array_push($missing, 'shortPwdlen');
	  }
	}


	
	
 }
 $missing = array();
 $n = 'Ant*';
 	 $checkName = '/^[a-zA-Z0-9_]+$/';
	if (!preg_match($checkName, $username)) {
	  array_push($missing, 'invalidUsername');
	  }
	var_dump($missing);
 ?>