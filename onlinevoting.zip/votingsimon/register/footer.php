
<div class="footer">
	<hr/>
&copy2018. Developed by WAMBUA SIMON MUTUKU: 89038.
<br/>
Online Voting System.
<br/>
Final Year Project 2019. STRATHMORE UNIVESITY 
<br/>
Contact: <a href="tel:+254704689286">+254714643906</a> | Email: <a href="mailtosimon.mutuku@strathmore.edu">mtkkyalo@gmail.com</a>

</div>
