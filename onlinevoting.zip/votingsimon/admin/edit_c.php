<?php 
error_reporting(0);
include ('session.php');
$msg = array();
?>
<?php include ('head.php');

if(ISSET($_POST['update'])){
    $bool = true;
    $position=$_POST['position'];
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $year_level=$_POST['year_level'];
    $gender=$_POST['gender'];
    $candidate_id=$_POST['candidate_id'];
    $image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
    $image_name= addslashes($_FILES['image']['name']);
    $image_size= getimagesize($_FILES['image']['tmp_name']);
    move_uploaded_file($_FILES["image"]["tmp_name"],"upload/" . $_FILES["image"]["name"]);			
    $location="upload/" . $_FILES["image"]["name"];

    $missing = array();
    $n = 'Ant';
         $checkName = '/^[a-zA-z]+$/';
       if (!preg_match($checkName, $firstname)) {
         array_push($missing, 'invalidUsername');
         }
         if (!preg_match($checkName, $lastname)) {
            array_push($missing, 'invalidUsername');
            }
if(empty($missing)){
    if($conn->query("UPDATE candidate SET position = '$position', firstname = '$firstname', lastname = '$lastname', year_level = '$year_level', gender = '$gender',img='$location' WHERE candidate_id = '$candidate_id'")){
        echo "<script> window.location='candidate.php' </script>";
    }
}else{
    $msg[] = 1;
}
}
?>

<body>
<?php include ('side_bar.php'); ?>
    <div id="wrapper">
    <!-- Page Content -->
    <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Candidate List</h3>
					<?php
                    if(isset($msg)){
                        foreach ($msg as $value) {
                            if($value = 1){ ?>
<p class="alert alert-danger">CHeck the input</p>
                         <?php   }
                        }
                    }
              ?>

        <!-- Navigation -->
        <?php 
if(isset($_GET['a'])){
    $no = $_GET['a'];
    require 'dbcon.php';
											$bool = false;
											$query = $conn->query("SELECT * FROM candidate WHERE candidate_id = $no");
												while($row = $query->fetch_array()){
													$candidate_id=$row['candidate_id'];
    ?>
<form method = "post" enctype = "multipart/form-data">	
				     <img src= <?php echo $row ['img']?> width="50" height="50" class="img-rounded">
					<input type="hidden" name="candidate_id" value="<?php echo $row['candidate_id'] ?>">
					<div class="form-group">
						<label>Position</label>
						<select class = "form-control" name = "position" value = "<?php echo $row ['position']?>">
						<option>President</option>
								<option>Vice President</option>
								<option>Chair Supervisory Committee</option>
								<option>Secretary Audit</option>
								<option>Chair F&A Committee</option>
								<option>Treasurer</option>
								<option>Secretary General</option>
								<option>Vice Treasurer</option>
								<option>Transport & Accommodation Secretary</option>
								<option>Chair Development Committee</option>
								<option>Vice Secretary General</option>
							</select>
					</div>
					<div class="form-group">
						<label>Department</label>
							<input class="form-control" type ="text" name = "party" value = "<?php echo $row ['party']?>">
					</div>
	
				
					<div class="form-group">
						<label>Firstname</label>
							<input class="form-control" type ="text" name = "firstname" required="true" value = "<?php echo $row ['firstname']?>">
					</div>
					<div class="form-group">
						<label>Lastname</label>
							<input class="form-control"  type = "text" name = "lastname" value = "<?php echo $row ['lastname']?>">
					</div>
					
					<div class="form-group">
						<label>Year_OF_Work</label>
							<select class = "form-control" name = "year_level">
								<option><?php echo $row ['year_level']?></option>
								<option></option>
								<option>1st Year</option>
								<option>2nd Year</option>
								<option>3rd Year</option>
								<option>4th Year</option>
								<option>5th Year</option>
								<option>6h Year</option>
								<option>n+1 Year</option>
							</select>
					</div>
					
					<div class="form-group">
						<label>Gender</label>
							<select class = "form-control" name = "gender">
								<option><?php echo $row ['gender']?></option>
								<option></option>
								<option>Male</option>
								<option>Female</option>
							</select>
					</div>
					<div class="form-group">
									<label>Image</label>
									<input type="file" name="image"> 
					</div>
					<button name = "update" type="submit" class="btn btn-primary">Save Data</button>
				</form>
<?php
}}
?>
